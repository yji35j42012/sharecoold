<div class="footer_box">
    <ul class="footer_nav">
        <li class="footer_nav_item fz14to12">品牌故事</li>
        <li class="footer_nav_item fz14to12"><a class="footer_nav_title" href="{{ route('contact') }}">聯絡我們</a></li>

        <li class="footer_nav_item fz14to12"><a class="footer_nav_title" href="rule.html">商標及應用準則</a></li>
        <li class="footer_nav_item fz14to12"><a class="footer_nav_title" href="usually.html">常用連結</a></li>
        <li class="footer_nav_item fz14to12"><a class="footer_nav_title" href="privacy.html">隱私權與政策</a></li>
    </ul>
    <ul class="footer_link">
        <li class="footer_link_icon _fb">
            <a href="https://www.facebook.com/Share.co.tw" target="_blank"></a>
        </li>
        <li class="footer_link_icon _ig">
            <a href="https://www.instagram.com/share.co.design/" target="_blank"></a>
        </li>
    </ul>
    <p class="copyRight">Copyright © 2023 SHARECO | All Rights Reserved</p>
</div>
